# RentRight GH — Handoff v12

**Supersedes:** nothing — this is a new app (`payments`), the next item
on the roadmap per v10/v11 (`negotiations app → payments app (Month 3)`).
All other app sections unchanged — refer back to v11 (`listings`), v10
(`negotiations`/`tenancies`/`documents`), v8 (`tenancies` retrofit) for
those.

---

## 1. Session recap

Built the `payments` app from scratch: Paystack integration (init +
verify), a webhook as the authoritative activation path, browser
callback for UX, instalment-schedule matching against the negotiated
`Proposal.instalment_schedule` JSON, and payment-receipt generation
wired into `documents`.

**⚠️ You don't have a Paystack account yet.** Nothing in this app has
been exercised against the real API — it's written to Paystack's
documented `/transaction/initialize`, `/transaction/verify`, and
webhook-signature contract, but treat the whole app as a structurally
complete draft, not a tested integration. Get test keys before relying
on any of this.

**Also flagged up front:** I only had `tenancies/models.py`,
`tenancies/services.py`, `negotiations/models.py` (partial — just
`Proposal`), and `documents/services.py` this session — not
`accounts/models.py`, `listings/models.py`, `applications/models.py`,
or `documents/models.py`. Several things below are inferred from how
those apps are referenced in the code I *do* have, not confirmed
against real definitions. Each is flagged individually where it matters
most, but the test factories in particular (`payments/tests/helpers.py`)
are a draft that needs a real test run against your project to shake
out field-name mismatches — same pattern as `tenancies`' three real
test-run passes in handoff v8 §2.10.

---

## 2. `payments` app — built this session

### 2.1 Model

`Payment` — one row per Paystack transaction attempt (move-in or a
single instalment).

- No per-instalment database row exists upstream — `negotiations.Proposal.instalment_schedule`
  is a plain JSON list (`[{"due_date": ..., "amount": ...}, ...]`), not
  a set of `ProposalInstalment` rows (that model only ever existed in
  the old v7 spec; v10's actual build collapsed it into JSON). So
  `Payment` carries its own `amount` / `instalment_due_date` snapshot,
  and instalment payments are matched back to a schedule entry by
  **due-date equality**, not a foreign key.
- `status` mirrors Paystack's own status strings (`pending` / `success`
  / `failed` / `abandoned`) directly rather than inventing RentRight
  names — `verify_and_record_payment()` can set it straight from
  Paystack's response with no translation table to drift out of sync.
- `gateway_response` (JSONField) stores the raw verify-response payload
  for audit — the same instinct as `Proposal`'s immutable chain: keep
  the raw record rather than only the derived fields, since a future
  dispute/reconciliation need is easy to predict and hard to retrofit.

**⚠️ No migration file generated** — same reason as every other app
this project: no migration history to chain against safely. Run
`python manage.py makemigrations payments && migrate` yourself.

### 2.2 Service layer (`payments/services.py`)

- `initiate_payment(tenancy, payer, payment_type, callback_url, instalment_due_date=None)`
  — creates a `PENDING` `Payment` row, then calls Paystack's
  `/transaction/initialize`. The row is saved **before** the network
  call and outside any atomic block with it, deliberately — it needs to
  durably exist even if Paystack is unreachable, so there's a record of
  the attempt. If the Paystack call fails, that same row is marked
  `FAILED` and the error re-raised, rather than left silently `PENDING`
  forever.
  - Guards: payer must be the tenant; `MOVE_IN` requires
    `PENDING_PAYMENT` status and no existing successful move-in payment;
    `INSTALMENT` requires `ACTIVE` status, a `due_date` matching an
    entry in the accepted `Proposal`'s schedule, and no existing
    successful payment against that due date.
- `verify_and_record_payment(reference)` — the single source of truth
  for "did this actually succeed." Always re-verifies against
  Paystack's own `/transaction/verify` endpoint rather than trusting the
  webhook payload or the browser callback's query string, per Paystack's
  own guidance — a hand-edited callback URL can't fake success this way.
  **Idempotent**: a `Payment` already `SUCCESS` short-circuits with no
  side effects re-run, since both the webhook and the callback can
  legitimately call this for the same reference.
- `_on_payment_success(payment)` — on a `MOVE_IN` success, calls
  `tenancies.services.activate_tenancy(tenancy, landlord=tenancy.landlord)`
  directly (this **is** the "Paystack webhook → `activate_tenancy()`"
  link from the original spec, replacing the manual landlord button).
  Passing `tenancy.landlord` straight through trivially satisfies
  `activate_tenancy()`'s ownership guard — same caveat as listings v11
  §5.2: there's no landlord↔delegate model, so this is fine as-is but
  would need revisiting if one gets built. Every success (move-in or
  instalment) also generates a Payment Receipt PDF and calls the SMS
  stub for both parties.
- `verify_webhook_signature(body, signature_header)` — HMAC-SHA512 of
  the raw request body against `PAYSTACK_SECRET_KEY`, compared with
  `hmac.compare_digest` (not `==`, which would be a timing
  side-channel on a security check).
- `get_instalment_schedule_with_status(tenancy)` /
  `get_overdue_instalments(tenancy)` — merge the accepted `Proposal`'s
  schedule with actual `Payment` rows so a template can render
  paid/due/overdue without doing its own date math.
- `check_overdue_instalments()` — plain function returning overdue rows
  across every `ACTIVE` tenancy, meant to become a Celery beat task per
  the original spec ("Celery tasks for instalment reminders"). **No
  Celery task or schedule is wired up this session** — this is the
  function such a task would call; for now it's callable from a shell
  or a management command you haven't written yet.
- **Deliberate asymmetry, flagged explicitly:** `formalise_special_conditions()`
  (tenancies app) and the SMS stubs degrade gracefully on failure — on
  purpose, since those are non-critical paths. Everything in this file
  does the opposite: a missing `PAYSTACK_SECRET_KEY` or an unreachable
  Paystack API **raises loudly** (`PaystackError`). Money must never
  silently pretend to succeed. Keep that asymmetry if this file grows.

### 2.3 `generate_default_notice()` — not built

The original spec marks this "optional." Deliberately not implemented:
a default/eviction notice is a much heavier legal document than a
receipt, and needs product + legal input on trigger conditions (how
many days overdue, what it has to say) before it's worth building.
`check_overdue_instalments()` surfaces the data a future version of
this would need; flagging rather than guessing at the content.

### 2.4 Views / URLs (`payments/views.py`, `payments/urls.py`)

- `initiate_move_in_payment_view` / `initiate_instalment_payment_view` —
  tenant-only, redirect to Paystack's `authorization_url` on success, or
  render a plain error page on `ValueError`/`PaystackError`.
- `payment_callback_view` — where Paystack redirects the payer's
  browser after checkout. **UX only** — re-verifies via
  `verify_and_record_payment()` rather than trusting the query string.
  Not `login_required`: the payer's session may have lapsed during the
  round-trip to Paystack's domain and back, and the reference (a UUID)
  is the actual authorization.
- `paystack_webhook_view` — the **authoritative** path.
  `@csrf_exempt` (Paystack isn't a browser session; authenticated via
  the HMAC signature instead), returns `200` even when the downstream
  verify call itself fails, so Paystack doesn't retry an event it
  received and authenticated correctly just because our verify call had
  a hiccup — the `Payment` row is left `PENDING` rather than marked
  falsely successful either way.
- `payment_history_view` — landlord-or-tenant-of-tenancy (mirrors the
  access pattern used in `documents`/`negotiations`), shows move-in
  status and the full instalment schedule with pay-now links.

URLs are self-contained in `payments/urls.py` (`app_name = "payments"`)
— one line to add to your root `urls.py`:
```python
path("payments/", include("apps.payments.urls", namespace="payments")),
```

### 2.5 Templates

`payment_result.html`, `payment_error.html`, `payment_history.html` —
built in Tailwind utility classes matching the recent `listings` work
(handoff v11). **Assumption flagged:** they extend
`accounts/dashboard_base.html`, matching `my_listings.html`'s
convention — but v11 §5.3 already flagged an unresolved mismatch
between `dashboard.html` and `dashboard_base.html` elsewhere in the
project. If that gets resolved, these three templates need the same
fix applied.

### 2.6 `documents` app changes

- **New:** `generate_payment_receipt(payment, generated_by=None)` in
  `documents/services.py`, following the exact same shape as
  `generate_rent_card()`/`generate_tenancy_agreement()`. Full updated
  `documents/services.py` included below (drop-in replacement).
- **Assumption flagged, needs your confirmation:** `DocumentType.PAYMENT_RECEIPT`
  is assumed to already exist — the original v7 spec listed it
  (`PAYMENT_RECEIPT = 'payment_receipt', 'Payment Receipt'`), but I
  don't have `documents/models.py` this session to confirm it actually
  made it into the real enum. If it's missing, add that line and run
  `makemigrations documents`.
- New template `documents/templates/documents/payment_receipt_template.html`
  — minimal, functional, explicitly **unstyled/not client-ready**, same
  status as `instalment_addendum_template.html` (v10 §4.4). No real
  receipt sample to match against yet, unlike the tenancy agreement
  (v10 §4.5).
- Reused `documents._financial_display_context()` and
  `_get_accepted_proposal()` from `payments/services.py` by importing
  them (both currently underscore-prefixed/"private" in `documents`).
  **Worth a call:** either leave this as-is (it's a same-project import,
  not a real encapsulation break), or rename both to drop the
  underscore now that a second app depends on them, so the "private"
  naming doesn't mislead a future reader. One-line rename either way —
  flagging, not deciding for you.

### 2.7 Tests

`payments/tests/test_services.py` — guard logic, idempotency, webhook
signature verification, and overdue-flagging, all with Paystack's HTTP
calls mocked (`@patch("apps.payments.services.requests.post/get")`).
`payments/tests/helpers.py` — test factories for `User`/`Property`/
`Application`/`Tenancy`/`Proposal`.

**Not run against your actual project this session** — I don't have
`accounts/models.py`, `listings/models.py`, or `applications/models.py`,
so field names in `helpers.py` (`email`, `phone_number`, `title`,
`monthly_rent`, `lease_term_months`, `move_in_date`, etc.) are inferred
from how they're referenced elsewhere, not confirmed. Expect a real run
to surface mismatches, the same way `tenancies`' suite took three real
passes to go green (handoff v8 §2.10) — this is a draft to iterate on,
not verified-passing tests. Share those three models.py files and I can
tighten this up without guessing.

### 2.8 New setting used (already in your snippet)

```python
PAYSTACK_SECRET_KEY  = config('PAYSTACK_SECRET_KEY',  default='')
PAYSTACK_PUBLIC_KEY  = config('PAYSTACK_PUBLIC_KEY',  default='')
```
`PAYSTACK_PUBLIC_KEY` isn't actually used by anything in this session's
code — it's only needed if a future version does client-side Paystack
Inline/Popup instead of the server-redirect flow (`authorization_url`)
built here. Left unused rather than wired in on spec.

---

## 3. File manifest — what was delivered this session

```
payments/
├── __init__.py
├── apps.py
├── admin.py
├── models.py                             (new — Payment, PaymentType, PaymentStatus)
├── services.py                           (new — Paystack integration, schedule matching)
├── views.py                              (new)
├── urls.py                               (new)
├── templates/payments/
│   ├── payment_result.html               (new)
│   ├── payment_error.html                (new)
│   └── payment_history.html              (new)
└── tests/
    ├── __init__.py
    ├── helpers.py                        (new — factories, unverified against real models)
    └── test_services.py                  (new — Paystack calls mocked throughout)

documents/
├── services.py                           (updated — generate_payment_receipt() added)
└── templates/documents/
    └── payment_receipt_template.html     (new — unstyled placeholder)
```

No migration file included — see §2.1.

---

## 4. Open items

1. **No Paystack account/keys** — everything here is written to spec,
   nothing has hit the real API. Get test keys and actually run the
   `initialize` → checkout → `verify`/webhook loop before trusting this.
2. **`accounts/models.py`, `listings/models.py`, `applications/models.py`,
   `documents/models.py` not yet shared** — several field-name
   assumptions in `payments/tests/helpers.py` and the
   `DocumentType.PAYMENT_RECEIPT` assumption in `documents/services.py`
   need confirming against these.
3. **Webhook route needs to be public and HTTPS in production** —
   Paystack has to be able to reach `payments:paystack_webhook` from the
   internet; if there's any auth middleware applied project-wide, this
   URL needs an explicit exemption (separate from the `@csrf_exempt`
   already on the view).
4. **`_financial_display_context()` / `_get_accepted_proposal()`
   underscore-privacy** — now imported cross-app from `payments`; worth
   a call on renaming (§2.6).
5. **Celery not wired up** — `check_overdue_instalments()` exists as a
   plain function but nothing schedules it. Needs the `notifications`
   app's Celery setup (Month 3) or an earlier ad-hoc `django-crontab`/
   management-command approach if instalment reminders are wanted
   sooner.
6. **`generate_default_notice()` not built** — needs product + legal
   input on trigger conditions before it's worth writing (§2.3).
7. All open items carried in v11 §5 and v10 §5 (archived-listing
   one-way-door decision, `edit_property.html` dead delegation banner,
   template-inheritance mismatch, `security_deposit`/`payment_cycle`
   read live instead of frozen, `has_instalment_plan` not checked by
   `open_negotiation()`, raw-OTP-as-reference, real SMS still a stub,
   `disputes` app not designed) are still open and untouched this
   session.

---

## 5. Roadmap

```
payments app (built this session — untested, no Paystack account yet)
   → maintenance app (Month 3)
   → disputes app (own app, not yet designed)
   → notifications app (Month 3 — unblocks real SMS everywhere, and
                          Celery for instalment reminders)
```
